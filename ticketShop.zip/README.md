# Informations
## Database
DB Name: epiz_33714139_ticket_shop_db
User Name: epiz_33714139
Password: mangamanga | ZGpLHDb4LkkB
HostName: sql202.epizy.com	


